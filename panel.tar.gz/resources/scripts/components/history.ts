import { createBrowserHistory } from "history";

export const browserHistory = createBrowserHistory({ basename: "/" });
